PVGIS seriescalc download package for the Seville PV-BESS thesis case
=====================================================================

This package is provided because the execution environment could not reach the PVGIS API directly.
Run the included script on any machine with internet access to download the official PVGIS seriescalc hourly PV output and align it to the load-data timeline.

Required official PVGIS dataset
-------------------------------
- Tool: PVGIS v5.3 seriescalc
- Location: Seville, Spain (37.4 N, -6.05 W)
- Years downloaded: 2011-2014
- PV system: 1 kWp, crystalline silicon, building-mounted
- Tilt: 30 degrees
- Aspect: 0 degrees (south-facing)
- System losses: 14%
- Radiation database: PVGIS-SARAH3

Load timeline to match
----------------------
- Start: 2011-12-06 13:00:00
- End: 2014-02-28 00:00:00
- Expected hourly rows: 19548

How to use
----------
1. Put this folder anywhere on your computer.
2. Open a terminal/command prompt in this folder.
3. Run:

   python download_and_align_PVGIS_seriescalc.py

4. The script will create:
   - PVGIS_Seville_1kWp_hourly_raw_2011_2014.csv
   - PVGIS_Seville_1kWp_aligned_to_load_timeline.csv
   - PVGIS_alignment_report.csv

The aligned CSV is the exact PV generation dataset to use as the baseline 1 kWp PV profile.
Scale it to any scenario PV size using:

   G_t = pv_generation_kwh_per_1kwp * PV_capacity_kWp

Direct browser URL
------------------
A direct CSV API URL is provided in PVGIS_API_URL_CSV.txt.
A JSON API URL used by the script is provided in PVGIS_API_URL_JSON.txt.

Important note
--------------
The file PVGIS_Seville_1kWp_aligned_to_load_timeline_TEMPLATE.csv only contains the correct timestamp structure. It is not the final PVGIS output. Run the script to populate official PVGIS values.
