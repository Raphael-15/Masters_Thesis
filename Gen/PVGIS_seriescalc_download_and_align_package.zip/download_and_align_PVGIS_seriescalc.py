#!/usr/bin/env python3
"""
Download and align PVGIS seriescalc hourly PV output for the Seville thesis case.

Purpose
-------
Creates the official PVGIS hourly PV generation dataset for:
- Location: Seville, Spain (37.4 N, -6.05 W)
- PV system: 1 kWp, crystalline silicon, building-mounted
- Tilt/Azimuth: 30 degrees / 0 degrees south-facing
- Losses: 14%
- PVGIS API: v5_3 seriescalc
- Years downloaded: 2011-2014
- Output aligned to the load-data timeline: 2011-12-06 13:00 to 2014-02-28 00:00

Requirements
------------
Run with internet access. Uses only the Python standard library.

Outputs
-------
1) PVGIS_Seville_1kWp_hourly_raw_2011_2014.csv
2) PVGIS_Seville_1kWp_aligned_to_load_timeline.csv
3) PVGIS_alignment_report.csv
"""
from urllib.parse import urlencode
from urllib.request import urlopen, Request
from datetime import datetime, timedelta
import json, csv, sys

LAT = 37.4
LON = -6.05
START_YEAR = 2011
END_YEAR = 2014
LOAD_START = datetime(2011, 12, 6, 13, 0, 0)
LOAD_END = datetime(2014, 2, 28, 0, 0, 0)
EXPECTED_ROWS = 19548
BASE_URL = "https://re.jrc.ec.europa.eu/api/v5_3/seriescalc"

PARAMS = {
    "lat": LAT,
    "lon": LON,
    "startyear": START_YEAR,
    "endyear": END_YEAR,
    "raddatabase": "PVGIS-SARAH3",
    "pvcalculation": 1,
    "peakpower": 1,
    "loss": 14,
    "angle": 30,
    "aspect": 0,
    "mountingplace": "building",
    "pvtechchoice": "crystSi",
    "trackingtype": 0,
    "outputformat": "json",
    "browser": 0,
}


def parse_pvgis_time(value):
    """Parse common PVGIS hourly timestamp formats."""
    text = str(value).strip()
    for fmt in ("%Y%m%d:%H%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y%m%d%H%M"):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    raise ValueError(f"Unrecognized PVGIS time format: {text}")


def normalize_hour(dt):
    # PVGIS timestamps are expected at hourly resolution. Keep as naive hourly timestamps
    # to match the provided load timeline convention.
    return dt.replace(minute=0, second=0, microsecond=0)


def fetch_pvgis_json():
    url = BASE_URL + "?" + urlencode(PARAMS)
    print("Downloading PVGIS JSON from:")
    print(url)
    req = Request(url, headers={"User-Agent": "Mozilla/5.0 thesis-data-script"})
    with urlopen(req, timeout=180) as response:
        raw = response.read().decode("utf-8")
    try:
        return json.loads(raw), url
    except json.JSONDecodeError:
        print("PVGIS did not return JSON. First 500 characters:")
        print(raw[:500])
        raise


def main():
    data, url = fetch_pvgis_json()
    hourly = data.get("outputs", {}).get("hourly")
    if not hourly:
        raise RuntimeError("Could not find outputs.hourly in PVGIS response.")

    rows = []
    for r in hourly:
        raw_time = r.get("time")
        dt = normalize_hour(parse_pvgis_time(raw_time))
        # PVGIS P is normally PV system output power in W for the specified peakpower.
        # For 1 kWp and one-hour timestep: kWh per kWp = P(W) / 1000.
        p_w = r.get("P", "")
        try:
            p_w_float = float(p_w)
            pv_kwh_per_kwp = p_w_float / 1000.0
        except (TypeError, ValueError):
            p_w_float = ""
            pv_kwh_per_kwp = ""
        rows.append({
            "ts_hour": dt.strftime("%Y-%m-%d %H:%M:%S"),
            "pvgis_time_raw": raw_time,
            "pv_power_w_per_1kwp": p_w_float,
            "pv_generation_kwh_per_1kwp": pv_kwh_per_kwp,
            "G_i_Wm2": r.get("G(i)", ""),
            "H_sun_deg": r.get("H_sun", ""),
            "T2m_C": r.get("T2m", ""),
            "WS10m_ms": r.get("WS10m", ""),
            "Int": r.get("Int", ""),
        })

    # Raw output
    fieldnames = ["ts_hour","pvgis_time_raw","pv_power_w_per_1kwp","pv_generation_kwh_per_1kwp","G_i_Wm2","H_sun_deg","T2m_C","WS10m_ms","Int"]
    with open("PVGIS_Seville_1kWp_hourly_raw_2011_2014.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)

    # Align to load timeline exactly
    by_ts = {r["ts_hour"]: r for r in rows}
    aligned = []
    missing = []
    t = LOAD_START
    while t <= LOAD_END:
        key = t.strftime("%Y-%m-%d %H:%M:%S")
        if key in by_ts:
            aligned.append(by_ts[key])
        else:
            missing.append(key)
            aligned.append({
                "ts_hour": key,
                "pvgis_time_raw": "",
                "pv_power_w_per_1kwp": "",
                "pv_generation_kwh_per_1kwp": "",
                "G_i_Wm2": "",
                "H_sun_deg": "",
                "T2m_C": "",
                "WS10m_ms": "",
                "Int": "",
            })
        t += timedelta(hours=1)

    with open("PVGIS_Seville_1kWp_aligned_to_load_timeline.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(aligned)

    annual_kwh = 0.0
    for r in aligned:
        try:
            annual_kwh += float(r["pv_generation_kwh_per_1kwp"])
        except (TypeError, ValueError):
            pass

    with open("PVGIS_alignment_report.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["metric", "value"])
        w.writerow(["source_url", url])
        w.writerow(["raw_rows", len(rows)])
        w.writerow(["aligned_start", LOAD_START.strftime("%Y-%m-%d %H:%M:%S")])
        w.writerow(["aligned_end", LOAD_END.strftime("%Y-%m-%d %H:%M:%S")])
        w.writerow(["aligned_rows", len(aligned)])
        w.writerow(["expected_rows", EXPECTED_ROWS])
        w.writerow(["missing_rows", len(missing)])
        w.writerow(["sum_pv_kwh_per_1kwp_aligned_period", round(annual_kwh, 6)])
        w.writerow(["note", "PV power P from PVGIS is converted from W to kWh/h per 1 kWp by dividing by 1000."])

    if len(aligned) != EXPECTED_ROWS:
        print(f"WARNING: aligned rows {len(aligned)} != expected {EXPECTED_ROWS}")
    if missing:
        print(f"WARNING: {len(missing)} missing PVGIS hours. See aligned CSV blank rows.")
    else:
        print("Success: no missing rows after alignment.")
    print("Created: PVGIS_Seville_1kWp_aligned_to_load_timeline.csv")


if __name__ == "__main__":
    main()
