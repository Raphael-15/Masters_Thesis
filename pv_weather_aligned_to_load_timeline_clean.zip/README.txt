PV/weather auxiliary inputs aligned to load-data timeline

Load file used as timeline reference: CC_LCL-FullData.xlsx
Load timeline identified: 2011-12-06 13:00:00 to 2014-02-28 00:00:00
Aligned resolution: hourly
Aligned hourly rows: 19548

Included CSV files:
1. GHI_DNI_aligned_to_load_timeline.csv
2. OpenMeteo_aligned_to_load_timeline.csv
3. PV_weather_auxiliary_inputs_aligned_to_load_timeline.csv
4. load_timeline_summary.csv
5. timeline_comparison_report.csv

The two PV/weather source files fully cover the load-data timeline, so missing rows after alignment are zero.

Note: these files are auxiliary irradiance/weather inputs. If the thesis baseline uses PVGIS seriescalc as the primary PV generation source, these aligned files should be treated as validation/diagnostic inputs, not as the baseline PV output.
